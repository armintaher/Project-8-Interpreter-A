//
// Created by armin on 12/3/2017.
//

#include "Parse.h"

void run();

int main(void){

    set_input("test_grader.blip");
    run();

    return 0;
}