//
// Created by armin on 12/3/2017.
//
//used 1/3 slip days

#include "Parse.h"

void run();

int main(void){

    set_input("test_grader.blip");
    run();

    return 0;
}